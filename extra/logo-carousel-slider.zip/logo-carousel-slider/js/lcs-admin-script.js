(function ($) {

	'use strict';
    $(document).ready(function($) {

       /* $('input[value="middle"], input[value="top_left"], input[value="bottom_left"], input[value="bottom_right"] ').click(function(){
            return false;
        });*/

        //$( '#lcs_slider_settings input, #lcs_style_settings input, #lcs_general_settings tbody > tr:nth-child(5) input, #lcs_general_settings tbody > tr:nth-child(4) input' ).prop( "disabled", true );

    });
})(jQuery);

